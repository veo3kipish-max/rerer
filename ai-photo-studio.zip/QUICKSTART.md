# 🚀 Быстрый старт

## За 3 минуты до первого запуска!

### 1️⃣ Установка (30 секунд)

```bash
npm install
```

### 2️⃣ Настройка (1 минута)

Создайте файл `.env.local`:

```bash
# Windows
copy .env.example .env.local

# Linux/Mac
cp .env.example .env.local
```

Откройте `.env.local` и добавьте ваш Gemini API ключ:

```env
GEMINI_API_KEY=ваш_ключ_здесь
```

**Где взять ключ?** → https://aistudio.google.com/apikey

### 3️⃣ Запуск (10 секунд)

```bash
npm run dev
```

Откройте → http://localhost:5173

**Готово!** 🎉 Приложение работает в демо-режиме авторизации.

---

## 🔐 Настройка настоящей авторизации (опционально)

### Google OAuth (5 минут)

1. Перейдите → https://console.cloud.google.com/
2. Создайте проект
3. APIs & Services → Credentials → Create OAuth Client ID
4. Добавьте `http://localhost:5173` в Authorized origins
5. Скопируйте Client ID в `.env.local`:

```env
VITE_GOOGLE_CLIENT_ID=ваш_client_id
```

### Telegram Bot (3 минуты)

1. Откройте → https://t.me/BotFather
2. Отправьте `/newbot` и следуйте инструкциям
3. Отправьте `/setdomain` и укажите `localhost`
4. Добавьте username бота в `.env.local`:

```env
VITE_TELEGRAM_BOT_USERNAME=ваш_бот
```

---

## 🌐 Деплой на Vercel (2 минуты)

### Вариант 1: CLI

```bash
npm install -g vercel
vercel login
vercel
```

### Вариант 2: GitHub

1. Загрузите код на GitHub
2. Перейдите → https://vercel.com
3. Import project → выберите репозиторий
4. Deploy!

**Не забудьте:** Добавить переменные окружения в Vercel Dashboard!

---

## 📚 Полная документация

- **README.md** - Подробная инструкция
- **DEPLOY.md** - Деплой на Vercel
- **AUTH_DOCS.md** - Техническая документация авторизации
- **CHANGELOG.md** - История изменений

---

## ⚡ Команды

```bash
npm run dev      # Запуск в режиме разработки
npm run build    # Сборка для production
npm run preview  # Предпросмотр production сборки
```

---

## 🆘 Помощь

**Проблемы с авторизацией?** → Проверьте `AUTH_DOCS.md` → Troubleshooting

**Проблемы с деплоем?** → Проверьте `DEPLOY.md` → Troubleshooting

**Другие вопросы?** → Откройте issue на GitHub

---

## 🎯 Основные возможности

✅ Авторизация через Google и Telegram  
✅ Генерация AI фотосессий  
✅ Настройка стиля, позы, макияжа  
✅ Режим селфи и повторения фото  
✅ Gemini 2.5 Flash и 3 Pro Vision  

---

**Приятного использования!** 🚀
