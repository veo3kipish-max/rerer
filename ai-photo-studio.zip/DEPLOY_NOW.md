# 🚀 Деплой ПРЯМО СЕЙЧАС - Пошаговая инструкция

## Вариант 1: Через Vercel Web Interface (САМЫЙ ПРОСТОЙ - 5 минут)

### Шаг 1: Создайте GitHub репозиторий

Если у вас нет Git, скачайте: https://git-scm.com/download/win

После установки Git:

```bash
# Откройте PowerShell в папке проекта и выполните:
git init
git add .
git commit -m "Initial commit - AI Photo Studio"
```

Затем на GitHub.com:
1. Создайте новый репозиторий (https://github.com/new)
2. Назовите его `ai-photo-studio`
3. НЕ добавляйте README, .gitignore или license
4. Скопируйте команды из раздела "push an existing repository"

```bash
git remote add origin https://github.com/ВАШ_USERNAME/ai-photo-studio.git
git branch -M main
git push -u origin main
```

### Шаг 2: Деплой на Vercel

1. Перейдите на https://vercel.com/login
2. Войдите через GitHub
3. Нажмите **"Add New Project"**
4. Выберите репозиторий `ai-photo-studio`
5. Vercel автоматически определит настройки (Vite)
6. Нажмите **"Deploy"**

### Шаг 3: Добавьте переменные окружения

После деплоя:
1. Откройте ваш проект в Vercel Dashboard
2. Перейдите в **Settings** → **Environment Variables**
3. Добавьте:
   - `GEMINI_API_KEY` = ваш ключ (ОБЯЗАТЕЛЬНО!)
   - `VITE_GOOGLE_CLIENT_ID` = ваш Google Client ID (опционально)
   - `VITE_TELEGRAM_BOT_USERNAME` = ваш бот (опционально)
4. Выберите все окружения (Production, Preview, Development)
5. Нажмите **Save**

### Шаг 4: Повторный деплой

1. Перейдите в **Deployments**
2. Нажмите на последний деплой
3. Нажмите три точки → **Redeploy**
4. Выберите **"Use existing Build Cache"**
5. Нажмите **Redeploy**

✅ **ГОТОВО!** Ваша ссылка будет вида: `https://ai-photo-studio-xxx.vercel.app`

---

## Вариант 2: Через Vercel CLI (если Git не работает)

### Требования:
- Node.js установлен (https://nodejs.org/)
- npm работает

### Команды:

```bash
# 1. Авторизация (откроется браузер)
vercel login

# 2. Деплой
vercel

# Ответьте на вопросы:
# Set up and deploy? → Yes
# Which scope? → Выберите ваш аккаунт
# Link to existing project? → No
# What's your project's name? → ai-photo-studio
# In which directory is your code located? → ./

# 3. Production деплой
vercel --prod
```

После деплоя добавьте переменные окружения через Dashboard (см. Вариант 1, Шаг 3).

---

## Вариант 3: Загрузка ZIP файла (БЕЗ GIT)

### Шаг 1: Подготовьте проект

1. Удалите папку `node_modules` (если есть)
2. Создайте ZIP архив всей папки проекта

### Шаг 2: Используйте Vercel CLI для загрузки

```bash
# В папке проекта:
vercel --prod
```

Vercel автоматически загрузит все файлы.

---

## ⚠️ ВАЖНО: После деплоя

### Для Google OAuth:
1. Откройте https://console.cloud.google.com/
2. Перейдите в ваш OAuth Client
3. Добавьте в **Authorized JavaScript origins**:
   - `https://ваш-проект.vercel.app`

### Для Telegram Bot:
1. Откройте @BotFather в Telegram
2. Отправьте `/setdomain`
3. Выберите вашего бота
4. Укажите: `ваш-проект.vercel.app` (БЕЗ https://)

---

## 🆘 Проблемы?

### "Git not found"
Скачайте: https://git-scm.com/download/win

### "Node.js not found"
Скачайте: https://nodejs.org/ (LTS версия)

### "Vercel command not found"
```bash
npm install -g vercel
```

### "Build failed"
Проверьте, что в проекте есть:
- `package.json`
- `vite.config.ts`
- Все файлы из папки `components/`

---

## 📞 Нужна помощь?

Если что-то не получается:
1. Скопируйте текст ошибки
2. Проверьте логи в Vercel Dashboard → Deployments → View Function Logs
3. Убедитесь, что все переменные окружения добавлены

---

**После успешного деплоя вы получите ссылку вида:**
```
https://ai-photo-studio-xxx.vercel.app
```

**Эту ссылку можно сразу открывать и использовать!** 🎉
