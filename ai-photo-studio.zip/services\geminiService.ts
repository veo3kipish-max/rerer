import { GoogleGenAI, Type } from "@google/genai";
import { PhotoshootPlan, UploadedImage } from "../types";

// Initialize the client
const getAiClient = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Step 1: Analyze inputs to create a cohesive photoshoot plan.
 * Uses gemini-2.5-flash for fast, reasoned analysis.
 */
export const planPhotoshoot = async (
  userPhotos: UploadedImage[],
  locationPhotos: UploadedImage[],
  locationText: string,
  userPrompt: string,
  tattooPhotos: UploadedImage[],
  tattooLocation: string,
  hairstylePhotos: UploadedImage[],
  hairstyleText: string,
  makeupPhotos: UploadedImage[],
  makeupText: string,
  outfitPhotos: UploadedImage[],
  outfitText: string,
  posePhotos: UploadedImage[],
  poseText: string,
  cameraAngles: string[] = [],
  imageCount: number = 5,
  isSelfieMode: boolean = false,
  isReplicateMode: boolean = false
): Promise<PhotoshootPlan> => {
  const ai = getAiClient();

  // Prepare image parts for all possible inputs
  const userImageParts = userPhotos.map(img => ({ inlineData: { data: img.base64Data, mimeType: img.mimeType } }));
  const locationImageParts = locationPhotos.map(img => ({ inlineData: { data: img.base64Data, mimeType: img.mimeType } }));
  const tattooImageParts = tattooPhotos.map(img => ({ inlineData: { data: img.base64Data, mimeType: img.mimeType } }));
  const hairstyleImageParts = hairstylePhotos.map(img => ({ inlineData: { data: img.base64Data, mimeType: img.mimeType } }));
  const makeupImageParts = makeupPhotos.map(img => ({ inlineData: { data: img.base64Data, mimeType: img.mimeType } }));
  const outfitImageParts = outfitPhotos.map(img => ({ inlineData: { data: img.base64Data, mimeType: img.mimeType } }));
  const poseImageParts = posePhotos.map(img => ({ inlineData: { data: img.base64Data, mimeType: img.mimeType } }));

  let textPrompt = "";
  let allImageParts = [...userImageParts, ...locationImageParts, ...tattooImageParts, ...hairstyleImageParts, ...makeupImageParts, ...outfitImageParts];

  const hasTattoos = tattooPhotos.length > 0;
  const hasStyleAddons = hairstylePhotos.length > 0 || hairstyleText.trim() !== '' || makeupPhotos.length > 0 || makeupText.trim() !== '' || outfitPhotos.length > 0 || outfitText.trim() !== '';

  if (isReplicateMode) {
    // --- REPLICATE / FACE SWAP MODE PROMPT ---
    textPrompt = `
      You are an expert AI photographer assistant. The user wants to perform a "Style Transfer" or "Subject Replacement".
      They have provided "Location/Reference Photos" and "User Photos".
      
      **Goal:** Create a plan to REPLICATE the "Location/Reference Photos" exactly (pose, composition, lighting, background) but replacing the person with the character from "User Photos".

      **Instructions:**
      1.  **Analyze Subject:** Describe the person in the "User Photos" (physique, face features, tattoos).
      2.  **Analyze Reference Scenes:** Look at the "Location Photos". These are the EXACT scenes to be recreated.
      3.  **Create Scenarios:** Generate ${imageCount} scenarios. 
          - If the user provided multiple Location Photos, map them to scenarios.
          - If there are fewer location photos than ${imageCount}, describe variations of the provided references.
          - The "Action", "Pose", and "Angle" MUST match the visual content of the Location Photos.

      **Output Requirement:**
      Return ONLY a single JSON object matching this structure:
      {
        "characterDescription": "Detailed physical description of the person from User Photos.",
        "outfitDescription": "Description of the outfit worn in the Location Photos (or User Photos if specified).",
        "locationDescription": "Description of the background/scene in the Location Photos.",
        "scenarios": [
          { "angle": "Same as reference", "pose": "Same as reference", "action": "Same as reference", "lighting": "Same as reference" }
        ]
      }
    `;
  } else if (isSelfieMode) {
    // --- SELFIE MODE PROMPT ---
    textPrompt = `
      You are a creative assistant planning a ${imageCount}-image selfie series. Your task is to generate a JSON plan.

      **Instructions:**
      1.  **Analyze Subject & Style:** Examine the user photos, general prompt ("${userPrompt}"), and any style add-ons (hairstyle, makeup, outfit, tattoos) to create a detailed description of the subject and a single, consistent style that will be used in ALL selfies.
      2.  **Analyze Background:** Use the location photos and text to describe a background setting for the selfies.
      3.  **Create Selfie Scenarios:** Design ${imageCount} scenarios. The "angle" must be a typical selfie angle (e.g., 'high-angle selfie', 'selfie in a mirror'). The "pose" and "action" must be natural for a person taking a selfie.

      **Output Requirement:**
      Return ONLY a single JSON object matching this structure:
      {
        "characterDescription": "Detailed physical description of the person, including any tattoos.",
        "outfitDescription": "Highly detailed description of the full look (outfit, hairstyle, makeup).",
        "locationDescription": "Detailed description of the background location.",
        "scenarios": [
          { "angle": "selfie angle", "pose": "selfie pose", "action": "selfie action", "lighting": "natural lighting" }
        ]
      }
    `;
  } else {
    // --- PHOTOSHOOT MODE PROMPT ---
    allImageParts.push(...poseImageParts);
    const hasPoseInput = posePhotos.length > 0 || poseText.trim() !== '';
    const hasCameraAngles = cameraAngles.length > 0;

    textPrompt = `
      You are a professional fashion art director planning a ${imageCount}-image photoshoot. Your task is to generate a JSON plan.

      **Instructions:**
      1.  **Analyze Subject & Style:** Examine the user photos, general prompt ("${userPrompt}"), and any style add-ons (hairstyle, makeup, outfit, tattoos) to create a detailed description of the subject and a single, consistent style for ALL photos.
      2.  **Analyze Location:** Use the location photos and text to define a unified background setting.
      3.  **Analyze Pose:** ${hasPoseInput ? "Examine the provided pose references. This specific pose MUST be the core basis for all scenarios." : "Decide on natural poses fitting the context."}
      4.  **Create Photoshoot Scenarios:** Design ${imageCount} detailed scenarios.
          ${hasCameraAngles ? `MANDATORY: You MUST use these camera angles across the scenarios: ${cameraAngles.join(', ')}.` : ""}

      **Output Requirement:**
      Return ONLY a single JSON object matching this structure:
      {
        "characterDescription": "Detailed physical description of the person, including any tattoos.",
        "outfitDescription": "Highly detailed description of the full look (outfit, hairstyle, makeup).",
        "locationDescription": "Detailed atmospheric description of the location.",
        "scenarios": [
          { "angle": "Camera angle", "pose": "Specific pose", "action": "What the subject is doing", "lighting": "Lighting specifics" }
        ]
      }
    `;
  }
  
  const parts = [{ text: textPrompt }, ...allImageParts];

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: parts },
      config: {
        responseMimeType: "application/json",
        safetySettings: [
          { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
          { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' },
          { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_NONE' },
          { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_NONE' },
        ]
      }
    });

    if (response.promptFeedback?.blockReason) {
      console.error("Plan generation blocked by API. Reason:", response.promptFeedback.blockReason);
      throw new Error(`Запрос заблокирован: ${response.promptFeedback.blockReason}. Пожалуйста, измените ваши изображения или текст.`);
    }

    if (!response.text || response.text.trim() === '') {
      console.error("Plan generation failed. The model returned no text. Full API Response:", JSON.stringify(response, null, 2));
      const candidate = response.candidates?.[0];
      const finishReason = candidate?.finishReason;
      if (finishReason === 'SAFETY') {
        throw new Error("План фотосессии заблокирован фильтрами безопасности. Попробуйте использовать другие изображения или текст.");
      }
      throw new Error(`Не удалось создать план фотосессии. Модель не вернула текст (Причина: ${finishReason || 'Неизвестно'}).`);
    }

    let plan: PhotoshootPlan;
    try {
        plan = JSON.parse(response.text) as PhotoshootPlan;
    } catch (jsonError) {
        console.error("Failed to parse JSON response from model. Raw text:", response.text);
        throw new Error("AI вернул некорректный формат плана. Пожалуйста, попробуйте снова.");
    }
    
    return plan;
    
  } catch (error: any) {
    console.error("Plan Photoshoot Error:", error);
    throw error;
  }
};

/**
 * Step 2: Generate a single image based on the plan and a reference photo.
 */
export const generateScenarioImage = async (
  plan: PhotoshootPlan,
  scenarioIndex: number,
  referencePhoto: UploadedImage, 
  positivePrompt: string,
  negativePrompt: string,
  useProModel: boolean = false,
  sceneReferencePhoto?: UploadedImage,
  isReplicateMode: boolean = false
): Promise<{ base64: string, prompt: string }> => {
  const ai = getAiClient();
  
  const safeIndex = scenarioIndex % plan.scenarios.length;
  const scenario = plan.scenarios[safeIndex];
  
  const mandatoryNegative = "distorted face, mutated features, blurry, plastic skin, unreal, bad anatomy, overexposed face";

  const facePreservationRule = `
    RULE:
    Always keep the person’s face exactly identical to the reference image. Do not change facial structure, proportions, eyes, nose, lips, jawline, skin tone, age, or unique features.
    The generated image must preserve:
    - identity (same face)
    - same facial geometry
    - same asymmetry
    - same skin details
    - same hairstyle unless user requests changes
    Do NOT beautify, alter, stylize, or correct the face unless explicitly instructed.
    When adding new scenes, outfits, lighting, or poses — the face must remain 100% identical to the reference, as if it is the exact same person photographed in another situation.
  `;

  let fullPrompt = "";
  const parts: any[] = [];

  if (isReplicateMode && sceneReferencePhoto) {
      // --- REPLICATION MODE ---
      fullPrompt = `
        TASK: IMAGE REPLICATION & FACE SWAP.
        
        INPUT 1 (Image): STRUCTURE REFERENCE (Scene, Pose, Lighting, Composition, Outfit).
        INPUT 2 (Image): FACE REFERENCE (Identity).
        
        INSTRUCTIONS:
        1. Generate an image that looks EXACTLY like the STRUCTURE REFERENCE (Input 1).
           - Copy the pose, action, camera angle, background, and lighting 100%.
           - Copy the outfit style and colors.
        2. Replace the person's face/identity with the FACE REFERENCE (Input 2).
           - ${facePreservationRule}
        
        Style: ${positivePrompt}
        Description: ${plan.characterDescription} in ${plan.locationDescription}.
        Avoid: ${negativePrompt}, ${mandatoryNegative}.
        
        High fidelity, 8k, photorealistic.
      `;

      parts.push({ text: fullPrompt });
      // Order is important: Structure Ref first, then Face Ref (usually works better for "Modify X with Y")
      parts.push({ inlineData: { data: sceneReferencePhoto.base64Data, mimeType: sceneReferencePhoto.mimeType } });
      parts.push({ inlineData: { data: referencePhoto.base64Data, mimeType: referencePhoto.mimeType } });

  } else {
      // --- STANDARD MODE ---
      fullPrompt = `
        Professional photography.
        Subject: ${plan.characterDescription}. 
        Wearing: ${plan.outfitDescription}.
        Location: ${plan.locationDescription}.
        Action: ${scenario.action}.
        Pose: ${scenario.pose}.
        Camera: ${scenario.angle}.
        Lighting: ${scenario.lighting}.
        Style: ${positivePrompt}.
        Avoid: ${negativePrompt}, ${mandatoryNegative}.
        
        ${facePreservationRule}
        
        High fidelity, 8k, photorealistic.
      `;

      parts.push({ text: fullPrompt });
      parts.push({ inlineData: { data: referencePhoto.base64Data, mimeType: referencePhoto.mimeType } });
  }

  const modelName = useProModel ? 'gemini-3-pro-image-preview' : 'gemini-2.5-flash-image';

  try {
    const response = await ai.models.generateContent({
      model: modelName, 
      contents: { parts: parts },
      config: {
         safetySettings: [
          { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
          { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' },
          { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_NONE' },
          { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_NONE' },
        ],
      }
    });

    const candidate = response.candidates?.[0];
    
    if (candidate?.finishReason === 'SAFETY') {
        throw new Error(`Изображение ${scenarioIndex + 1} заблокировано фильтрами безопасности.`);
    }

    let base64Image = "";
    for (const part of candidate?.content?.parts || []) {
      if (part.inlineData) {
        base64Image = part.inlineData.data;
        break;
      }
    }

    if (!base64Image) {
      const textPart = candidate?.content?.parts?.find(p => p.text)?.text;
      if (textPart) {
          console.warn("Model returned text instead of image:", textPart);
          throw new Error("Модель отказалась генерировать изображение: " + textPart);
      }
      throw new Error("Не удалось сгенерировать изображение для сценария " + (scenarioIndex + 1));
    }

    return {
      base64: base64Image,
      prompt: fullPrompt
    };
  } catch (error: any) {
    console.error(`Generate Image ${scenarioIndex} Error (Model: ${modelName}):`, error);
    throw error;
  }
};