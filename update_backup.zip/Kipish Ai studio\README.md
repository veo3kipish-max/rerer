<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# AI Фотостудия - Студия AI Фотосессий

Создавайте профессиональные фотосессии с помощью AI, используя модели Gemini.

View your app in AI Studio: https://ai.studio/apps/drive/1FZbCPZkjHRQeqZTn8P1XlgmR-VjOpnfM

## Возможности

- 🔐 **Авторизация через Google и Telegram**
- 📸 **Генерация профессиональных фотосессий**
- 🎨 **Настройка стиля, позы, макияжа и наряда**
- 🖼️ **Режим селфи и повторения фото**
- ⚡ **Использование Gemini 2.5 Flash и Gemini 3 Pro Vision**

## Запуск локально

**Требования:** Node.js 16+

### 1. Установите зависимости

```bash
npm install
```

### 2. Настройте переменные окружения

Создайте файл `.env.local` на основе `.env.example`:

```bash
cp .env.example .env.local
```

#### Настройка Gemini API

Добавьте ваш Gemini API ключ в `.env.local`:

```env
GEMINI_API_KEY=your_gemini_api_key_here
```

Получить API ключ: https://aistudio.google.com/apikey

#### Настройка Google OAuth (опционально)

1. Перейдите в [Google Cloud Console](https://console.cloud.google.com/)
2. Создайте новый проект или выберите существующий
3. Перейдите в **APIs & Services > Credentials**
4. Нажмите **Create Credentials > OAuth 2.0 Client ID**
5. Выберите тип приложения: **Web application**
6. Добавьте **Authorized JavaScript origins**:
   - `http://localhost:5173` (для разработки)
   - Ваш production URL (для деплоя)
7. Скопируйте Client ID и добавьте в `.env.local`:

```env
VITE_GOOGLE_CLIENT_ID=your_google_client_id_here
```

#### Настройка Telegram Bot (опционально)

1. Откройте Telegram и найдите [@BotFather](https://t.me/BotFather)
2. Отправьте команду `/newbot` и следуйте инструкциям
3. Получите username бота (например, `my_photo_bot`)
4. Настройте домен для авторизации:
   - Отправьте `/setdomain` в @BotFather
   - Выберите вашего бота
   - Укажите домен (например, `localhost` для разработки или ваш production домен)
5. Добавьте username бота в `.env.local`:

```env
VITE_TELEGRAM_BOT_USERNAME=my_photo_bot
```

**Примечание:** Если вы не настроите Google OAuth и Telegram Bot, приложение будет работать в демо-режиме авторизации.

### 3. Запустите приложение

```bash
npm run dev
```

Приложение будет доступно по адресу: http://localhost:5173

## Деплой на Vercel

1. Установите Vercel CLI:

```bash
npm install -g vercel
```

2. Запустите деплой:

```bash
vercel
```

3. Настройте переменные окружения в Vercel Dashboard:
   - `GEMINI_API_KEY`
   - `VITE_GOOGLE_CLIENT_ID` (опционально)
   - `VITE_TELEGRAM_BOT_USERNAME` (опционально)

4. Не забудьте обновить:
   - **Google OAuth**: Добавьте production URL в Authorized JavaScript origins
   - **Telegram Bot**: Обновите домен через `/setdomain` в @BotFather

## Технологии

- **React 19** - UI библиотека
- **TypeScript** - Типизация
- **Vite** - Сборщик
- **Gemini AI** - Генерация изображений
- **Google OAuth** - Авторизация через Google
- **Telegram Login Widget** - Авторизация через Telegram

## Лицензия

MIT
