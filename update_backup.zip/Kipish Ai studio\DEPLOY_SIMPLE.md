# 🚀 ПРОСТОЙ СПОСОБ ДЕПЛОЯ - БЕЗ GIT

## Используем Vercel CLI напрямую

Поскольку у вас уже установлен Vercel CLI, давайте задеплоим проект напрямую из папки.

### Шаг 1: Откройте обычную командную строку (CMD)

**НЕ PowerShell!** Откройте CMD:
1. Нажмите `Win + R`
2. Введите `cmd`
3. Нажмите Enter

### Шаг 2: Перейдите в папку проекта

```cmd
cd d:\Projects\1123
```

### Шаг 3: Авторизуйтесь в Vercel

```cmd
vercel login
```

Это откроет браузер. Войдите с вашими данными:
- Email: nickkipish@gmail.com
- Password: hell19929278

### Шаг 4: Деплой проекта

```cmd
vercel --prod
```

Vercel задаст вопросы:
1. **Set up and deploy?** → Нажмите `Y` (Yes)
2. **Which scope?** → Выберите ваш аккаунт (стрелками, Enter)
3. **Link to existing project?** → Нажмите `N` (No)
4. **What's your project's name?** → Введите `ai-photo-studio` (или любое имя)
5. **In which directory is your code located?** → Нажмите Enter (оставить `./`)

Vercel начнет загрузку и деплой!

### Шаг 5: Получите ссылку

После завершения деплоя вы увидите:
```
✅ Production: https://ai-photo-studio-xxx.vercel.app
```

**ЭТО ВАША ССЫЛКА!** 🎉

---

## ⚠️ ВАЖНО: После деплоя

### Добавьте переменные окружения

1. Откройте: https://vercel.com/nicks-projects-00786ef7
2. Найдите проект `ai-photo-studio`
3. Откройте его → **Settings** → **Environment Variables**
4. Добавьте:
   - **Name:** `GEMINI_API_KEY`
   - **Value:** (ваш Gemini API ключ)
   - Выберите все окружения (Production, Preview, Development)
   - Нажмите **Save**

5. Вернитесь в **Deployments**
6. Нажмите на последний деплой → три точки → **Redeploy**

---

## 🆘 Если что-то не работает

### Ошибка "vercel: command not found"

Установите Vercel CLI:
```cmd
npm install -g vercel
```

Если npm не работает, установите Node.js:
https://nodejs.org/ (скачайте LTS версию)

### Ошибка "npm: command not found"

Установите Node.js:
https://nodejs.org/

После установки перезапустите CMD и попробуйте снова.

---

## 📝 Полная последовательность команд

```cmd
cd d:\Projects\1123
vercel login
vercel --prod
```

Вот и всё! Через 2-3 минуты у вас будет работающая ссылка! 🚀
