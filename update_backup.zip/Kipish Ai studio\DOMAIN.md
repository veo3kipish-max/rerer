# 🌐 Домен kipish.fun

Проект развернут на домене: **http://kipish.fun**

## Настройки для kipish.fun

### Google OAuth
Убедитесь, что в Google Cloud Console добавлен домен:
- Authorized JavaScript origins: `http://kipish.fun`

### Telegram Bot
Настройте домен через @BotFather:
```
/setdomain
[Выберите бота]
kipish.fun
```

### Vercel
Домен kipish.fun должен быть подключен в настройках Vercel:
1. Settings → Domains
2. Add Domain: `kipish.fun`

## Production URL
**http://kipish.fun**
