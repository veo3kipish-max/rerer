# 🚀 ФИНАЛЬНЫЙ ДЕПЛОЙ - Пошаговая инструкция

## ✅ У вас уже есть:
- Vercel проект: https://nextjs-boilerplateai-photo-studio.vercel.app
- Код проекта в: d:\Projects\1123

## 📥 Шаг 1: Установите Git (5 минут)

1. Скачайте Git:
   - Откройте: https://git-scm.com/download/win
   - Нажмите "Click here to download" (64-bit)
   - Запустите установщик
   - Нажимайте "Next" везде (настройки по умолчанию)
   - Нажмите "Install"
   - Нажмите "Finish"

2. Проверьте установку:
   - Нажмите `Win + R`
   - Введите `cmd` и нажмите Enter
   - Введите: `git --version`
   - Должна появиться версия Git

## 📥 Шаг 2: Установите Node.js (5 минут)

1. Скачайте Node.js:
   - Откройте: https://nodejs.org/
   - Нажмите на зеленую кнопку "LTS" (рекомендуемая версия)
   - Запустите установщик
   - Нажимайте "Next" везде
   - Нажмите "Install"
   - Нажмите "Finish"

2. Проверьте установку:
   - Откройте новое окно CMD (важно - новое!)
   - Введите: `node --version`
   - Введите: `npm --version`
   - Должны появиться версии

## 📦 Шаг 3: Инициализируйте Git репозиторий (2 минуты)

Откройте CMD и выполните:

```cmd
cd d:\Projects\1123

git init

git add .

git commit -m "AI Photo Studio - initial commit"
```

Вы должны увидеть сообщения о создании репозитория и добавлении файлов.

## 🌐 Шаг 4: Создайте GitHub репозиторий (3 минуты)

### Если у вас НЕТ GitHub аккаунта:

1. Перейдите на: https://github.com/signup
2. Зарегистрируйтесь (бесплатно)
3. Подтвердите email

### Создайте репозиторий:

1. Перейдите на: https://github.com/new
2. **Repository name:** `ai-photo-studio`
3. **Description:** AI Photo Studio - Gemini powered photo generation
4. Выберите **Public** (или Private, если хотите)
5. **НЕ** ставьте галочки на:
   - Add a README file
   - Add .gitignore
   - Choose a license
6. Нажмите **"Create repository"**

## 🔗 Шаг 5: Загрузите код на GitHub (2 минуты)

После создания репозитория GitHub покажет команды. Скопируйте и выполните в CMD:

```cmd
git remote add origin https://github.com/ВАШ_USERNAME/ai-photo-studio.git

git branch -M main

git push -u origin main
```

**ВАЖНО:** Замените `ВАШ_USERNAME` на ваш реальный username на GitHub!

GitHub может попросить авторизацию:
- Введите ваш GitHub username
- Введите ваш GitHub password (или Personal Access Token)

## 🔄 Шаг 6: Подключите GitHub к Vercel (3 минуты)

### Вариант A: Через браузер (ПРОЩЕ)

1. Откройте: https://vercel.com/nicks-projects-00786ef7
2. Найдите проект `ai-photo-studio`
3. Откройте его
4. Перейдите в **Settings** → **Git**
5. Нажмите **"Connect Git Repository"**
6. Выберите **GitHub**
7. Авторизуйте Vercel на GitHub (если попросит)
8. Выберите репозиторий `ai-photo-studio`
9. Нажмите **"Connect"**

### Вариант B: Создать новый проект

1. Откройте: https://vercel.com/new
2. Нажмите **"Continue with GitHub"**
3. Авторизуйте Vercel (если попросит)
4. Выберите репозиторий `ai-photo-studio`
5. Нажмите **"Import"**
6. Vercel автоматически определит настройки (Vite)
7. Нажмите **"Deploy"**

## ⚙️ Шаг 7: Добавьте переменные окружения (2 минуты)

После подключения репозитория:

1. Откройте проект в Vercel Dashboard
2. Перейдите в **Settings** → **Environment Variables**
3. Добавьте переменную:
   - **Name:** `GEMINI_API_KEY`
   - **Value:** (вставьте ваш Gemini API ключ)
   - Выберите все окружения: Production, Preview, Development
   - Нажмите **"Save"**

4. (Опционально) Добавьте:
   - `VITE_GOOGLE_CLIENT_ID` - если настроили Google OAuth
   - `VITE_TELEGRAM_BOT_USERNAME` - если настроили Telegram Bot

## 🚀 Шаг 8: Запустите деплой (1 минута)

1. Перейдите в **Deployments**
2. Нажмите на последний деплой
3. Нажмите три точки (⋮) → **"Redeploy"**
4. Выберите **"Use existing Build Cache"**
5. Нажмите **"Redeploy"**

Подождите 2-3 минуты...

## ✅ ГОТОВО!

Ваш проект будет доступен по ссылке:
**https://ai-photo-studio-xxx.vercel.app**

(точная ссылка будет показана после деплоя)

---

## 🔄 Автоматические обновления

Теперь каждый раз, когда вы делаете изменения в коде:

```cmd
cd d:\Projects\1123

git add .

git commit -m "Описание изменений"

git push
```

Vercel автоматически задеплоит новую версию! 🎉

---

## 🆘 Troubleshooting

### Git не работает после установки

Перезапустите CMD (закройте и откройте новое окно).

### GitHub просит токен вместо пароля

1. Перейдите: https://github.com/settings/tokens
2. Нажмите **"Generate new token"** → **"Classic"**
3. Выберите срок действия и права (repo)
4. Скопируйте токен
5. Используйте его вместо пароля

### Vercel не видит репозиторий

1. Перейдите: https://vercel.com/account/login-connections
2. Переподключите GitHub
3. Дайте доступ к репозиторию

### Ошибка при деплое

1. Проверьте логи в Vercel Dashboard → Deployments → View Function Logs
2. Убедитесь, что `GEMINI_API_KEY` добавлен
3. Проверьте, что все файлы загружены на GitHub

---

## 📞 Нужна помощь?

Если что-то не получается на каком-то шаге:
1. Скопируйте текст ошибки
2. Скажите на каком шаге возникла проблема
3. Я помогу решить!

---

**Удачи! Через 20 минут у вас будет полностью рабочее приложение на Vercel!** 🚀
