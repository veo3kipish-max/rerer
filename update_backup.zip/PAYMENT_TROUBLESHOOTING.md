# 🔧 Устранение проблем с Telegram Payments

## Проблема: Платеж застревает на "Processing payment..."

### Симптомы:
- Попытка оплаты через Telegram Wallet
- Появляется диалог "Подтвердите действие на странице kipish.fun"
- Платеж не завершается

---

## 🔍 Диагностика

### Шаг 1: Проверьте Bot Token

1. Откройте @BotFather в Telegram
2. Отправьте: `/mybots`
3. Выберите: **АИ фотосессия!**
4. Нажмите: **API Token**
5. Скопируйте токен

**Формат:** `1234567890:ABCdefGHIjklMNOpqrsTUVwxyz`

### Шаг 2: Проверьте Provider Token в BotFather

1. В @BotFather выберите вашего бота
2. Нажмите: **Payments**
3. Проверьте, какой провайдер подключен

**Важно:** Если там указано:
- ✅ **"Ammer Pay"** или **"Custom"** - это правильно
- ❌ **"Telegram Stars"** или **"Wallet Pay"** - это другая система!

### Шаг 3: Проверьте переменные окружения в Supabase

1. Откройте: https://supabase.com/dashboard
2. Выберите ваш проект
3. **Settings** → **Edge Functions** → **Secrets**

У вас должны быть:
```
TELEGRAM_BOT_TOKEN=ваш_bot_token
TELEGRAM_PROVIDER_TOKEN_TEST=6073714100:TEST:TG_0Hu7mBvcM_aynsU1VNlN9r8A
TELEGRAM_PROVIDER_TOKEN_LIVE=5775769170:LIVE:TG_W86WACpRtP4FJUebpZTbzm8A
```

---

## 🚀 Решение 1: Проверка подключения Ammer Pay

### 1.1. Отвязать старый провайдер (если нужно)

Если в BotFather подключен не Ammer Pay:

1. @BotFather → `/mybots`
2. Выберите бота
3. **Payments** → **Remove provider**

### 1.2. Подключить Ammer Pay заново

1. @BotFather → `/mybots`
2. Выберите: **АИ фотосессия!**
3. Нажмите: **Payments**
4. Выберите: **Custom** (или найдите Ammer Pay в списке)
5. Вставьте **TEST Provider Token**: `6073714100:TEST:TG_0Hu7mBvcM_aynsU1VNlN9r8A`

✅ Сохраните

---

## 🚀 Решение 2: Исправление кода (если нужно)

### 2.1. Проверить, что используется правильный метод

В `create-telegram-invoice` мы используем `createInvoiceLink`, что правильно для Ammer Pay.

**НЕ правильно:** `sendInvoice` (для прямых сообщений)

### 2.2. Убедитесь, что вызов правильный

Откройте консоль браузера (F12) и проверьте:

```javascript
// Должно быть:
tg.openInvoice(invoice_url, callback)

// НЕ должно быть:
tg.openLink(invoice_url)
```

---

## 🚀 Решение 3: Использовать альтернативный метод

Если Ammer Pay не работает, можно использовать **Telegram Stars**.

### Преимущества Stars:
- ✅ Нет необходимости в провайдере
- ✅ Встроенная система Telegram
- ✅ Быстрая оплата

### Недостатки:
- ❌ Пользователи платят в Stars, а не в гривнах
- ❌ Конвертация Stars → UAH

**Хотите переключиться на Stars?** Дайте знать, я обновлю код.

---

## 🧪 Тестирование: Проверьте логи

### Откройте Supabase Edge Functions Logs

1. Supabase Dashboard → **Edge Functions**
2. Выберите: **create-telegram-invoice**
3. Нажмите: **Logs**

**Что искать:**
- ✅ "Telegram API response: { ok: true }" - всё работает
- ❌ "Error: Bad Request: invalid provider token" - неправильный токен
- ❌ "Credentials missing" - не установлены переменные

---

## ✅ Быстрая проверка

Выполните эти действия по порядку:

### ☑️ Checklist:

- [ ] Bot Token получен из @BotFather
- [ ] Provider Token добавлен в @BotFather → Payments
- [ ] Переменные окружения добавлены в Supabase
- [ ] Edge Function задеплоена (`supabase functions deploy create-telegram-invoice`)
- [ ] Приложение открывается через Telegram бота
- [ ] В консоли браузера нет ошибок 401/403

---

## 💡 Следующие шаги

После проверки всех пунктов:

1. Перезапустите Telegram
2. Откройте бота заново: @ai_stud_ai_bot
3. Нажмите на кнопку меню внизу
4. Попробуйте купить пакет

**Если всё равно не работает:**
- Скиньте скриншот логов из Supabase
- Проверьте консоль браузера (F12)
- Дайте знать, какая ошибка появляется

---

## 🆘 Частые ошибки

### "Invalid provider token"
➜ Provider Token в Supabase не совпадает с тем, что в @BotFather

### "Payment provider not set"
➜ В @BotFather не подключен провайдер к боту

### "Bad Gateway"
➜ Edge Function не задеплоена или недоступна

### "Authorize first"
➜ Приложение открыто не через Telegram бота

---

## 📞 Нужна помощь?

Давайте вместе проверим логи и найдём проблему!
